"""Generate every formal manuscript table from final-release data and numerical outputs."""
from pathlib import Path
import argparse,csv,json,math,gzip
p=argparse.ArgumentParser();p.add_argument('--results',default='outputs');p.add_argument('--out',default='paper/tables');args=p.parse_args()
repo=Path(__file__).resolve().parent;res=Path(args.results).resolve();tab=Path(args.out).resolve();tab.mkdir(parents=True,exist_ok=True)
def rows(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def empirical(n):return rows(res/'empirical'/(n+'.csv'))
def num(r,k):return float(r[k])
def f(x,d=4):return f'{float(x):.{d}f}'
def esc(s):return str(s).replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')
sources={}
def table(name,label,title,headers,data,files,notes='',spec=None):
 t='\\begin{table}[!htbp]\n\\centering\\small\n'+f'\\caption{{{title}}}\\label{{{label}}}\n'
 t+='\\begin{tabular}{'+(spec or 'l'+'r'*(len(headers)-1))+'}\n\\toprule\n'+' & '.join(headers)+r' \\'+'\n\\midrule\n'
 t+='\n'.join(' & '.join(esc(v)for v in r)+r' \\'for r in data)+'\n\\bottomrule\n\\end{tabular}\n'
 if notes:t+='\\par\\smallskip{\\footnotesize '+notes+'}\n'
 t+='\\end{table}\n';(tab/(name+'.tex')).write_text(t,encoding='utf-8');sources[name]=files
cr=lambda v:sum(v)**2/(sum(v)**2+sum(1-x*x for x in v))
a=[.7,.1];b=[.5,.5];rot=lambda v:[(v[0]-v[1])/math.sqrt(2),(v[0]+v[1])/math.sqrt(2)]
table('compcr','tab:cr','Basis Dependence of a Coordinate-Sum Reliability Statistic',['Indicator','Reference basis','45-degree rotation','Squared norm'],[[n,f(cr(v)),f(cr(rot(v))),f(sum(x*x for x in v))]for n,v in [('A',a),('B',b)]],['Formula in run_checks.R'],notes='This arithmetic counterexample is not used as a reliability estimate.')
mc=rows(res/'simulation'/'benchmark_replicates.csv');ms=rows(res/'simulation'/'benchmark_summary.csv');cb=rows(res/'factor_ml'/'CBSEM_replicates.csv');cs=rows(res/'factor_ml'/'CBSEM_summary.csv')
table('run_scope','tab:scope','Monte Carlo Design and Computational Scope',['Quantity','Value'],[['Scenarios','1, 2, 3'],['Sample sizes','100, 500, 2000'],['Equation targets','.5, .8, .9'],['Replications per setting','200'],['Generated samples',str(len(mc)//4)],['Comparator outputs',str(len(mc))]],['simulation/benchmark_replicates.csv'],notes='Four outputs per sample: ILR with coordinate standardization, ILR with whole-item scaling, matched CLR, and latent-factor oracle. The paired ML study uses 200 additional samples.')
rt=rows(res/'simulation'/'rotation_differences.csv')+empirical('rotations');rotation_data=[]
for dataset,display in [('scenario1','Scenario 1'),('scenario2','Scenario 2'),('scenario3','Scenario 3'),('empirical','Application')]:
 rs=[r for r in rt if r['dataset']==dataset];first=next(r for r in rs if r['rotation']=='45deg')
 rotation_data.append([display,str(len(rs)),f'{num(first,"legacy_path"):.2e}',f'{max(num(r,"legacy_path")for r in rs):.2e}',f'{num(first,"path"):.2e}',f'{max(num(r,"path")for r in rs):.2e}'])
table('rotation','tab:rotation','Path Sensitivity to ILR Basis Changes',['Data','Rotations',r'Coord. $45^\circ$','Coord. max',r'Whole $45^\circ$','Whole max'],rotation_data,['simulation/rotation_differences.csv','empirical/rotations.csv'],notes='Coord.: separate coordinate standardization with equal weights reset in each basis. Whole: trace scaling and transported weights. Differences compare each fitted procedure with its own reference-basis solution after score-sign alignment. The metric-only control, which transports initialization for both procedures, is also supplied. All comparisons use the same observations.')
bm=[]
for si in [1,2,3]:
 for method in ['ILR-column','ILR-trace','CLR-trace','oracle']:
  r=next(r for r in ms if int(r['scenario'])==si and int(r['n'])==500 and float(r['R2'])==.8 and r['method']==method)
  bm.append([si,method,*[f(r['bias'+k])for k in ['21','31','32']],f(math.sqrt(sum(num(r,'rmse'+k)**2 for k in ['21','31','32'])/3))])
table('benchmark','tab:benchmark','Common-Factor Path Errors at $n=500$ and $R^2=(.8,.8)$',['Scenario','Method','Bias 21','Bias 31','Bias 32','Pooled RMSE'],bm,['simulation/benchmark_summary.csv'],notes='Errors use the population coefficients after equation-specific rescaling. Pooled RMSE averages squared errors over all replications and the three paths. The factor oracle is unavailable in practice.')
cbd=[]
for si in [2,3]:
 r=next(r for r in cs if int(r['scenario'])==si);a=[r for r in cb if int(r['scenario'])==si]
 cbd.append([si,'Factor ML',r['admissible']+'/'+r['attempts'],*[f(r['bias'+k])for k in ['21','31','32']],f(math.sqrt(sum(num(r,'rmse'+k)**2 for k in ['21','31','32'])/3))])
 errors=[[num(r,'PLS'+k)-num(r,'truth'+k)for k in ['21','31','32']]for r in a]
 cbd.append([si,'ILR-trace',str(sum(r['PLS_converged']=='TRUE'for r in a))+'/'+str(len(a)),*[f(sum(e[j]for e in errors)/len(errors))for j in range(3)],f(math.sqrt(sum(x*x for e in errors for x in e)/(len(errors)*3)))])
table('cbsem','tab:cbsem','Paired Factor-ML and PLS Comparison',['Scenario','Method','Usable/attempted','Bias 21','Bias 31','Bias 32','RMSE'],cbd,['factor_ml/CBSEM_replicates.csv','factor_ml/CBSEM_summary.csv'],notes='Each scenario uses 100 paired samples at $n=500$ and $R^2=(.8,.8)$. ML means use admissible fits with denominators reported. PLS scores and common factors have different regression targets. The unrestricted single-item model in Scenario 1 is not identified.')
me=empirical('measurement');paths=empirical('paths');r2=empirical('R2')
table('measurement','tab:measurement','Descriptive Measurement Assessment ($N=506$)',['Item','Loading magnitude','Explained logratio variance'],[[r['item'],f(r['loading_norm']),f(r['explained_logratio_variance'])]for r in me],['empirical/measurement.csv'],notes='Primary multiplicative replacement is 0.5 percentage points. Loading magnitudes use raw ILR units; variance fractions describe an in-sample single-score projection and are not reliability or validity estimates.')
table('paths','tab:paths','Structural Model Estimates',['Source','Target','Estimate','Bootstrap SE',r'95\% lower',r'95\% upper'],[[r['source'],r['target'],*[f(r[k])for k in ['estimate','bootstrap_SE','lower','upper']]]for r in paths],['empirical/paths.csv','empirical/R2.csv'],notes='Respondent bootstrap: '+paths[0]['successful']+'/'+paths[0]['requested']+' successful primary fits. Endogenous score $R^2$: '+', '.join(r['construct']+' '+f(r['R2'],6)for r in r2 if r['R2']!='NA')+'. IS denotes the relative influence-source profile; coefficients are score associations conditional on the stated metric and orientation.')
pr=empirical('prediction');pdata=[]
for r in pr:
 for label,prefix in [('PLS','PLS'),('Linear model','LM'),('Training center','Center')]:pdata.append([r['item'],label,f(r[prefix+'_Aitchison_RMSE']),f(r[prefix+'_mean_Aitchison'])])
table('prediction','tab:prediction','Out-of-Sample Prediction Performance',['Item','Predictor','Aitchison RMSE','Mean Aitchison distance'],pdata,['empirical/prediction.csv','empirical/cv_folds.csv'],notes='The same ten folds and primary zero approximation are used. PLS and the linear model receive only IS root inputs. The center predictor uses the training-sample compositional center of each outcome item and no covariates.')
sens=empirical('zero_sensitivity');r2all=empirical('R2_all_methods');names={'multiplicative':'Multiplicative','additive_smoothing':'All-part smoothing','zero_only_closure':'Zero-only + closure'}
table('sensitivity','tab:sensitivity','Sensitivity to Zero-Processing Choices',['Scheme','Value (pp)','Max path change','BI score $R^2$','Successful bootstrap'],[[names[r['family']],f(r['delta_pp'],3),f(r['max_path_change']),f(next(t['R2']for t in r2all if t['method']==r['method']and t['construct']=='BI')),str(2000-int(r['bootstrap_failed']))+'/2000']for r in sens],['empirical/zero_sensitivity.csv','empirical/paths_all_methods.csv','empirical/R2_all_methods.csv'],notes='Values are percentage points on a 100-point scale. Reference: multiplicative 0.5. All 1,827 observed zero components are processed. The 0.001 settings are near-boundary stress controls. Complete path intervals and prediction metrics are supplied for all settings.')
items=rows(repo/'data'/'items.csv');t=r'''\begin{longtable}{lp{2.0cm}p{9.2cm}}
\caption{Questionnaire Items and Composition Definitions}\label{tab:items}\\
\toprule Item & Question & Wording \\
\midrule\endfirsthead
\toprule Item & Question & Wording \\
\midrule\endhead
'''
for r in items:t+=esc(r['item'])+' & '+esc(r['question_number'])+' & '+esc(r['wording'])+r' \\'+'\n'
t+=r'''\bottomrule
\end{longtable}
\noindent Each Attitude, PBC and BI item is one three-part allocation in the order agreement, disagreement and neutrality. The IS composition allocates relative influence to Family, Friends and Other non-family. Every allocation totals 100. Original questionnaire numbers identify the retained items; displayed item labels are sequential within constructs.
''';(tab/'items.tex').write_text(t,encoding='utf-8');sources['items']=['data/items.csv','data/dictionary.csv']
(tab/'table_sources.json').write_text(json.dumps(sources,indent=2),encoding='utf-8')
print(json.dumps({'tables':len(sources),'path':str(tab),'center_predictor_added':True},indent=2))

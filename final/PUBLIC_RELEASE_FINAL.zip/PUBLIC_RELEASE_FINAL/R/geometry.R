# Definitions extracted from the audited revision; see PROVENANCE.md.
Closure <- function(x) x/apply(x, 1, sum)

helm <- function(n) {
    mat <- matrix(0, n - 1, n)
    i <- 2:n
    r <- 1/sqrt(i * (i - 1))
    for (j in 1:(n - 1)) {
        mat[n - j, 1:(j + 1)] <- c(rep(r[j], j), -j * r[j])
    }
    return(mat)
}

gmean <- function(x) exp(mean(log(x)))

clr <- function(x) {
    if (ncol(x) == 1) 
        return(x)
    gm <- apply(x, 1, gmean)
    log(x/gm)
}

ilr <- function(x) {
    D <- ncol(x)
    as.matrix(clr(x)) %*% t(helm(D))
}


# Definitions extracted from the audited revision; see PROVENANCE.md.
ilrinv <- function(z, psi) {
    a <- z %*% psi
    a <- exp(a - apply(a, 1, max))
    a/rowSums(a)
}

std <- function(x) {
    x <- as.matrix(x)
    x <- sweep(x, 2, colMeans(x))
    sweep(x, 2, sqrt(colSums(x * x)/(nrow(x) - 1)), "/")
}

blockdiag <- function(ms) {
    out <- matrix(0, sum(sapply(ms, nrow)), sum(sapply(ms, ncol)))
    i <- j <- 0
    for (m in ms) {
        out[i + seq_len(nrow(m)), j + seq_len(ncol(m))] <- m
        i <- i + nrow(m)
        j <- j + ncol(m)
    }
    out
}

maxabs <- function(x) max(abs(x))

orth <- function(k) {
    q <- qr.Q(qr(matrix(rnorm(k * k), k)))
    q
}

rot45 <- function(k) {
    q <- diag(k)
    q[1:2, 1:2] <- matrix(c(1, 1, -1, 1), 2)/sqrt(2)
    q
}

fit <- function(Z, groups, edges, items, mode = "trace", init = NULL, maxit = 1000, tol = 1e-10) {
    Z <- as.matrix(Z)
    n <- nrow(Z)
    p <- ncol(Z)
    G <- length(groups)
    mu <- colMeans(Z)
    X <- sweep(Z, 2, mu)
    sc <- rep(1, p)
    if (mode == "column") 
        sc <- sqrt(colSums(X * X)/(n - 1))
    if (mode == "trace") 
        for (j in items) sc[j] <- sqrt(sum(X[, j, drop = FALSE]^2)/(n - 1))
    if (any(sc <= 0)) 
        stop("Zero variance block")
    X <- sweep(X, 2, sc, "/")
    W <- matrix(0, p, G)
    if (is.null(init)) 
        init <- lapply(groups, function(j) rep(1, length(j)))
    for (g in seq_len(G)) W[groups[[g]], g] <- init[[g]]
    adj <- matrix(0, G, G)
    adj[edges] <- 1
    dep <- unique(edges[, 2])
    oldT <- std(X %*% W)
    conv <- FALSE
    for (it in seq_len(maxit)) {
        C <- cor(oldT)
        E <- C * t(adj)
        for (g in dep) {
            pa <- which(adj[, g] != 0)
            E[pa, g] <- qr.solve(oldT[, pa, drop = FALSE], oldT[, g])
        }
        U <- oldT %*% E
        for (g in seq_len(G)) {
            j <- groups[[g]]
            w <- drop(crossprod(X[, j, drop = FALSE], U[, g])/(n - 1))
            score <- drop(X[, j, drop = FALSE] %*% w)
            s <- sd(score)
            if (s < 1e-14) 
                stop("Degenerate score")
            if (sum(score * oldT[, g]) < 0) 
                w <- -w
            W[j, g] <- w/s
        }
        T <- X %*% W
        delta <- maxabs(T - oldT)
        oldT <- T
        if (delta < tol) {
            conv <- TRUE
            break
        }
    }
    P <- matrix(0, G, G)
    r2 <- rep(NA_real_, G)
    for (g in dep) {
        pa <- which(adj[, g] != 0)
        b <- qr.solve(T[, pa, drop = FALSE], T[, g])
        P[pa, g] <- b
        r2[g] <- 1 - sum((T[, g] - T[, pa, drop = FALSE] %*% b)^2)/sum(T[, g]^2)
    }
    L <- matrix(0, p, G)
    for (g in seq_len(G)) {
        j <- groups[[g]]
        L[j, g] <- crossprod(sweep(Z[, j, drop = FALSE], 2, mu[j]), T[, g])/(n - 1)
    }
    list(scores = T, P = P, r2 = r2, L = L, W = W, mean = mu, scale = sc, iterations = it, converged = conv, delta = delta, 
        groups = groups, edges = edges, items = items)
}

predictfit <- function(m, Z) {
    X <- sweep(sweep(as.matrix(Z), 2, m$mean), 2, m$scale, "/")
    G <- ncol(m$P)
    T <- matrix(0, nrow(Z), G)
    for (g in seq_len(G)) {
        pa <- m$edges[m$edges[, 2] == g, 1]
        if (length(pa)) 
            T[, g] <- T[, pa, drop = FALSE] %*% m$P[pa, g]
        else T[, g] <- X %*% m$W[, g]
    }
    sweep(T %*% t(m$L), 2, m$mean, "+")
}

alignfit <- function(m, reference) {
    s <- sign(colSums(m$scores * reference$scores))
    s[s == 0] <- 1
    m$scores <- sweep(m$scores, 2, s, "*")
    m$L <- sweep(m$L, 2, s, "*")
    m$W <- sweep(m$W, 2, s, "*")
    m$P <- m$P * outer(s, s)
    m
}

strength <- function(m, Z, itemnames, itemconstruct) {
    do.call(rbind, lapply(seq_along(m$items), function(i) {
        j <- m$items[[i]]
        g <- itemconstruct[i]
        total <- sum(apply(Z[, j, drop = FALSE], 2, var))
        l <- m$L[j, g]
        data.frame(item = itemnames[i], construct = g, dimension = length(j), loading_norm = sqrt(sum(l * l)), 
            explained_logratio_variance = sum(l * l)/total, residual_trace = total - sum(l * l))
    }))
}

rotation_test <- function(Z, groups, edges, items, psis, label, ntest = 25L) {
    a <- fit(Z, groups, edges, items)
    old <- fit(Z, groups, edges, items, "column")
    ans <- list()
    for (b in seq_len(ntest)) {
        qs <- lapply(items, function(j) if (b == 1) 
            rot45(length(j))
        else orth(length(j)))
        Q <- blockdiag(qs)
        Zr <- Z %*% t(Q)
        init <- lapply(groups, function(j) drop(Q[j, j, drop = FALSE] %*% rep(1, length(j))))
        ar <- alignfit(fit(Zr, groups, edges, items, init = init), a)
        oldr <- alignfit(fit(Zr, groups, edges, items, "column"), old)
        scaler <- alignfit(fit(Zr, groups, edges, items, "column", init = init), old)
        initr <- alignfit(fit(Zr, groups, edges, items), a)
        backL <- t(Q) %*% ar$L
        targetpred <- predictfit(ar, Zr) %*% Q
        invdiff <- max(sapply(seq_along(items), function(i) {
            j <- items[[i]]
            g <- which(sapply(groups, function(x) all(j %in% x)))
            maxabs(ilrinv(matrix(a$L[j, g], 1), psis[[i]]) - ilrinv(matrix(ar$L[j, g], 1), qs[[i]] %*% psis[[i]]))
        }))
        ans[[b]] <- data.frame(dataset = label, rotation = if (b == 1) 
            "45deg"
        else paste0("random", b - 1), path = maxabs(a$P - ar$P), R2 = max(abs(a$r2 - ar$r2), na.rm = TRUE), scores = maxabs(a$scores - 
            ar$scores), loading_covariance = maxabs(a$L - backL), loading_coordinate_change = maxabs(a$L - ar$L), 
            inverse_ilr = invdiff, predictions = maxabs(predictfit(a, Z) - targetpred), legacy_path = maxabs(old$P - 
                oldr$P), legacy_scores = maxabs(old$scores - oldr$scores), scale_only_path = maxabs(old$P - scaler$P), 
            init_only_path = maxabs(a$P - initr$P), converged = ar$converged)
    }
    do.call(rbind, ans)
}


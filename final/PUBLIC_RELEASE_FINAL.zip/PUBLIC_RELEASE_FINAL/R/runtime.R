# Base-R command-line and repository bootstrap. No package installation on startup.
parse_options <- function(defaults) {
  args <- commandArgs(TRUE)
  if ("--help" %in% args) {
    cat("Options (use --name=value):\n")
    for(n in names(defaults)) cat(" --",n,"=",defaults[[n]],"\n",sep="")
    quit(status=0)
  }
  for(a in args) {
    if(!grepl("^--[a-z-]+=.+$",a)) stop("Expected --name=value; got: ",a)
    pair <- strsplit(sub("^--","",a),"=",fixed=TRUE)[[1]]
    key<-pair[1]; value<-paste(pair[-1],collapse="=")
    if(!key %in% names(defaults)) stop("Unknown option: ",key)
    defaults[[key]]<-value
  }
  defaults
}
positive_int <- function(x,name) {
  v<-suppressWarnings(as.numeric(x))
  if(length(v)!=1||!is.finite(v)||v<1||v!=floor(v))stop(name," must be a positive integer")
  as.integer(v)
}
load_core <- function(repo) {
  for(n in c("geometry.R","estimator.R","scenarios.R","zero_handling.R"))source(file.path(repo,"R",n),local=.GlobalEnv)
}
prepare_output <- function(p) {
  dir.create(p,recursive=TRUE,showWarnings=FALSE)
  if(!dir.exists(p))stop("Cannot create output directory: ",p)
  normalizePath(p,winslash="/")
}
record_session <- function(out) {
  writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
  writeLines(c("RNG: Mersenne-Twister / Inversion / Rejection","Defaults are documented in README.md."),file.path(out,"run_environment.txt"))
}
options(warn=1)

# Definitions extracted from the audited revision; see PROVENANCE.md.
replace_item <- function(a, family, delta) {
    p <- a/100
    if (family == "multiplicative") 
        for (r in seq_len(nrow(p))) {
            z <- p[r, ] == 0
            k <- sum(z)
            if (k) {
                p[r, z] <- delta/100
                p[r, !z] <- p[r, !z] * (1 - k * delta/100)
            }
        }
    if (family == "additive_smoothing") 
        p <- (a + delta)/(100 + ncol(a) * delta)
    if (family == "zero_only_closure") {
        p <- a
        p[p == 0] <- delta
        p <- p/rowSums(p)
    }
    stopifnot(all(p > 0), maxabs(rowSums(p) - 1) < 1e-12)
    p
}


# Definitions extracted from the audited revision; see PROVENANCE.md.
scenarios <- list(list(load = list(c(0.689, 0.183, 0.128), c(0.637, 0.181, 0.104, 0.078), c(0.465, 0.236, 0.132, 
    0.088, 0.079)), assign = 1:3, b = 0.48), list(load = list(c(0.689, 0.182, 0.128), c(0.648, 0.224, 0.128), c(0.569, 
    0.23, 0.201), c(0.638, 0.181, 0.104, 0.077), c(0.578, 0.181, 0.141, 0.1), c(0.449, 0.155, 0.136, 0.118, 0.141), 
    c(0.422, 0.227, 0.138, 0.09, 0.124)), assign = c(1, 1, 1, 2, 2, 3, 3), b = 0.28), list(load = list(c(0.689, 
    0.182, 0.129), c(0.648, 0.224, 0.128), c(0.415, 0.279, 0.155, 0.151), c(0.707, 0.18, 0.113), c(0.561, 0.215, 
    0.134, 0.09), c(0.443, 0.215, 0.233, 0.109), c(0.483, 0.147, 0.172, 0.097, 0.101), c(0.537, 0.288, 0.175), 
    c(0.549, 0.18, 0.108, 0.163), c(0.456, 0.172, 0.156, 0.125, 0.091)), assign = c(1, 1, 1, 2, 2, 2, 2, 3, 3, 
    3), b = 0.28))

setup <- function(s, R2) {
    slopes <- lapply(s$load, function(x) drop(ilr(matrix(x, nrow = 1))))
    p <- sum(lengths(slopes))
    end <- cumsum(lengths(slopes))
    its <- lapply(seq_along(end), function(i) seq.int(if (i == 1) 1 else end[i - 1] + 1, end[i]))
    gr <- lapply(1:3, function(g) unlist(its[s$assign == g]))
    L <- matrix(0, p, 3)
    for (i in seq_along(its)) L[its[[i]], s$assign[i]] <- slopes[[i]]
    B <- matrix(c(0, 0.36, 0.76, 0, 0, s$b, 0, 0, 0), 3)
    S <- diag(3)
    for (g in 2:3) {
        pa <- seq_len(g - 1)
        B[g, pa] <- B[g, pa] * sqrt(R2[g - 1]/drop(B[g, pa, drop = FALSE] %*% S[pa, pa, drop = FALSE] %*% B[g, 
            pa]))
        S[g, pa] <- B[g, pa] %*% S[pa, pa, drop = FALSE]
        S[pa, g] <- S[g, pa]
    }
    theta <- 1 - rowSums(L * L)
    if (any(theta < 0)) 
        stop("Invalid original coordinate loadings: negative residual variance")
    list(L = L, B = B, S = S, theta = theta, items = its, groups = gr, psis = lapply(s$load, function(x) helm(length(x))))
}

generate <- function(st, n) {
    latent <- matrix(rnorm(n * 3), n) %*% chol(st$S)
    Z <- latent %*% t(st$L) + sweep(matrix(rnorm(n * nrow(st$L)), n), 2, sqrt(st$theta), "*")
    list(Z = Z, latent = latent)
}


# Formal manuscript source

`manuscript.tex` is the final standalone paper. Its ten tables are generated from this release; there are no external figure files or private LaTeX inputs.

After `python reproduce.py`, run `python build_manuscript.py`. Install Tectonic or latexmk independently, or supply `--engine=/path/to/tectonic`. For a custom results directory, pass the same directory through `--results`. The PDF is written to `outputs/paper/FINAL_MANUSCRIPT.pdf`. TeX package installation/caching is managed by the selected engine and may require network access on first use. The authors' private audit and reviewer correspondence are not part of this public analysis release.

# PLS-SEM for compositional data - final analysis

This directory is the version entry for the final manuscript, **PLS-SEM for compositional data: coordinate invariance and measurement assessment**. It contains the authorized pseudonymized 506-record dataset and everything required to regenerate its final numerical tables. Use this directory rather than legacy scripts or workbooks elsewhere in the repository.

## Run the complete final table workflow

Requirements: R (tested originally with 4.6.1 and for this release with 4.6.2) and Python 3.10+ (standard library only for table generation). The default route does not require any additional R package:

```sh
python reproduce.py
```

If Rscript is not on PATH, specify it with `--rscript=/path/to/Rscript`. An output location can be supplied with `--out=/path/to/output`.

The default `--mode=verified` route checks the supplied numerical-input hashes, regenerates Monte Carlo and factor-ML summaries from the completed replication draws, refits the empirical point models from the released observations, redoes rotations and fixed-fold predictions, derives intervals from the saved bootstrap draws, and produces every final LaTeX table. It does **not** claim to be a fresh rerun of all 5,400 simulations or 16,000 bootstrap attempts.

To regenerate every random sample and fit from the specified seeds:

```sh
# Optional lavaan is needed only for the factor-ML recomputation:
# in R: install.packages("lavaan")
python reproduce.py --mode=recompute
```

Both modes use only files in this directory. Full recomputation takes substantially longer. The verified route preserves the completed numerical experiment without unnecessary reruns. The files under `verified/` are numerical draws used in the final tables, not raw private audit files.

The editable formal source is in `paper/manuscript.tex`. After the numerical workflow, `python build_manuscript.py` compiles it using an independently installed Tectonic or latexmk. See `paper/README.md`.

## Dataset and measures

`data/analysis.csv` is the sole observation dataset: one row per participant, 33 observed allocation components, a release-specific anonymous ID, fixed cross-validation fold and a unique-profile matching flag. Original zero observations are retained; replacing them is part of the executable protocol. No original questionnaire IDs, source Excel row numbers, timestamps, IP addresses or demographics are included.

Ten items allocate 100 points to agreement, disagreement and neutrality. The independent IS composition allocates 100 points to Family, Friends and Other non-family. It is a relative influence-source profile, not a validated measure of perceived social approval. There are 504 unique profile matches and two records assigned under a disclosed order-preserving assumption; `unique_profile_match=FALSE` identifies them. Original source-linkage records are held privately. The corresponding author confirmed permission to publicly release both sets of pseudonymized allocations on 31 October 2026.

`data/dictionary.csv`, `data/items.csv` and `data/README.md` give the full wording, original item numbers, part order, matching assumptions and zero-processing rules. Column names follow the final paper: Att1-4, PBC1-3, BI1-3 and IS. Old outcome-derived nominal SN coordinates are not used or distributed in this version.

## Interpretation

The method controls coordinate artifacts for a specified PLS score procedure. Coordinate invariance for compositional PLS regression is established prior work: Chen, Zhang and Hron (2021), DOI: 10.1080/02664763.2020.1795813. The path-model conditions concern whole-item scaling, transported initialization, coupled score updates and score-space convergence. They are not a claim of new logratio geometry or common-factor consistency.

Loading magnitude and explained total logratio variance are descriptive; COMP-CR is not used as reliability. The common-factor ML comparison has lower factor-path RMSE in the reported settings. The application’s root-only prediction does not outperform training-sample compositional centers. Data matching, zero mechanisms and construct interpretation remain substantive limitations.

## Entry points and contents

- `reproduce.py`: complete one-command numerical/table workflow.
- `run_final.R`: verified replay or full numerical recomputation.
- `run_empirical.R`: current data, eight zero approximations, bootstrap, prediction and sensitivity.
- `run_simulation.R`, `run_factor_benchmark.R`: full scenario and optional ML computations.
- `run_checks.R`: mathematical/rotation checks, exact coordinate-sum counterexample and target-R-squared verification.
- `make_tables.py`: all ten final table files, including item wording appendix.
- `verified/`: completed Monte Carlo, ML and bootstrap draws and scenario rotations.
- `docs/`: scientific scope, software versions, version changes and input provenance.

All old numerical outputs and audit correspondence are outside this release. `VERSION_NOTES.md` preserves the material version/data correction statement. No new software or data reuse license has been selected on the authors' behalf; see `NOTICE.md`.

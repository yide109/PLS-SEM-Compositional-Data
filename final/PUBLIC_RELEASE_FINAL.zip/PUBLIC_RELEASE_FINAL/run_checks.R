# Locate the repository from this script, independent of the working directory.
if(.Platform$OS.type=="windows"&&!isTRUE(l10n_info()[["UTF-8"]]))invisible(suppressWarnings(try(Sys.setlocale("LC_CTYPE",".UTF-8"),silent=TRUE)))
script_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value=TRUE)[1])
repo <- dirname(normalizePath(script_file, winslash="/", mustWork=TRUE))
source(file.path(repo,"R","runtime.R"))
load_core(repo)
opt<-parse_options(list(out=file.path(repo,"results","checks")))
out<-prepare_output(opt$out);record_session(out);RNGkind("Mersenne-Twister","Inversion","Rejection")
checks<-list();add<-function(name,error,tol=1e-7){checks[[length(checks)+1]]<<-data.frame(check=name,max_error=error,tolerance=tol,passed=is.finite(error)&&error<tol)}
for(D in 3:7){psi<-helm(D);set.seed(20261031+D);x<-exp(matrix(rnorm(60*D),60,D));add(paste0("basis_D",D),maxabs(psi%*%t(psi)-diag(D-1)));add(paste0("roundtrip_D",D),maxabs(ilrinv(ilr(x),psi)-x/rowSums(x)))}
for(i in 1:3){set.seed(4000+i);st<-setup(scenarios[[i]],c(.8,.8));g<-generate(st,120);r<-rotation_test(g$Z,st$groups,rbind(c(1,2),c(1,3),c(2,3)),st$items,st$psis,paste0("scenario",i),4);write.csv(r,file.path(out,paste0("scenario",i,"_rotations.csv")),row.names=FALSE);for(k in c("path","R2","scores","loading_covariance","inverse_ilr","predictions"))add(paste(i,k,sep="_"),max(r[[k]]))}
# Exact reviewer pair: arithmetic counterexample only; not a reliability proposal.
withdrawn_cr<-function(l)sum(l)^2/(sum(l)^2+sum(1-l*l))
q<-matrix(c(1,1,-1,1),2)/sqrt(2);l<-list(c(1,.2),c(.7,.7));a<-sapply(l,withdrawn_cr);b<-sapply(l,function(z)withdrawn_cr(drop(q%*%z)))
tab<-data.frame(item=c("MV1","MV2"),original=a,rotated=b,norm_squared=sapply(l,function(z)sum(z*z)))
write.csv(tab,file.path(out,"COMP_CR_withdrawn_counterexample.csv"),row.names=FALSE)
stopifnot(a[1]<a[2],b[1]>b[2]);add("reviewer_exact_values",maxabs(c(a,b)-c(.6,1.96/2.98,2/2.96,.49)))
raw<-rbind(c(100,0,0),c(60,30,10));m<-replace_item(raw,"multiplicative",.5)
add("MR_sum",maxabs(rowSums(m)-1));add("MR_example",maxabs(m[1,]-c(.99,.005,.005)));add("positive_composition_unchanged",maxabs(m[2,]-raw[2,]/100))
st<-setup(scenarios[[2]],c(.5,.9));add("heterogeneous_R2",maxabs(c(st$B[2,1]^2,drop(st$B[3,1:2,drop=FALSE]%*%st$S[1:2,1:2]%*%st$B[3,1:2]))-c(.5,.9)))
ans<-do.call(rbind,checks);write.csv(ans,file.path(out,"checks.csv"),row.names=FALSE);print(ans)
if(!all(ans$passed))stop("A mathematical/numerical check failed")
cat("All checks passed.\n")

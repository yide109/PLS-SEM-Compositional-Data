# Locate the repository from this script, independent of the working directory.
if(.Platform$OS.type=="windows"&&!isTRUE(l10n_info()[["UTF-8"]]))invisible(suppressWarnings(try(Sys.setlocale("LC_CTYPE",".UTF-8"),silent=TRUE)))
script_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value=TRUE)[1])
repo <- dirname(normalizePath(script_file, winslash="/", mustWork=TRUE))
source(file.path(repo,"R","runtime.R"))
load_core(repo)
opt<-parse_options(list(reps="100",out=file.path(repo,"results","factor_benchmark")))
reps<-positive_int(opt$reps,"reps")
if(!requireNamespace("lavaan",quietly=TRUE))stop("Optional benchmark requires lavaan. Install it explicitly with install.packages('lavaan').")
out<-prepare_output(opt$out);record_session(out);RNGkind("Mersenne-Twister","Inversion","Rejection")
savecsv<-function(x,name)write.csv(x,file.path(out,paste0(name,".csv")),row.names=FALSE)

 cbfit<-function(z,st,targetL=st$L) {
  colnames(z)<-paste0('z',1:ncol(z));lines<-character()
  for(g in 1:3) lines<-c(lines,paste0('F',g,' =~ ',paste(colnames(z)[st$groups[[g]]],collapse=' + ')))
  lines<-c(lines,'F2 ~ F1','F3 ~ F1 + F2')
  for(j in st$items) if(length(j)>1)for(a in 1:(length(j)-1))for(b in (a+1):length(j))lines<-c(lines,paste0('z',j[a],' ~~ z',j[b]))
  fitcb<-suppressWarnings(lavaan::sem(paste(lines,collapse='\n'),data=as.data.frame(z),meanstructure=FALSE))
  if(!lavaan::lavInspect(fitcb,'converged'))stop('CBSEM nonconvergence')
  ss<-lavaan::standardizedSolution(fitcb);sel<-which(ss$op=='~');out<-ss[sel,c('lhs','rhs','est.std')]
  pe<-lavaan::parameterEstimates(fitcb);res<-pe$est[pe$op=='~~'&pe$lhs==pe$rhs&grepl('^z',pe$lhs)]
  sg<-setNames(rep(1,3),paste0('F',1:3))
  for(g in 1:3){ld<-pe[pe$op=='=~'&pe$lhs==paste0('F',g),];sg[g]<-sign(sum(ld$est*targetL[as.integer(sub('z','',ld$rhs)),g]))}
  out$est.std<-out$est.std*sg[out$lhs]*sg[out$rhs]
  vc<-try(lavaan::lavInspect(fitcb,'vcov'),silent=TRUE)
  list(paths=out,admissible=all(res>=0)&&min(eigen(lavaan::lavInspect(fitcb,'theta'),symmetric=TRUE,only.values=TRUE)$values)>-1e-8&&!inherits(vc,'try-error')&&all(is.finite(vc)))
 }
 set.seed(20261029);res<-list();k<-0
 for(si in 2:3){st<-setup(scenarios[[si]],c(.8,.8));for(b in seq_len(reps)){gg<-generate(st,500)
  pf<-fit(gg$Z,st$groups,rbind(c(1,2),c(1,3),c(2,3)),st$items)
  cb<-try(cbfit(gg$Z,st),silent=TRUE);p<-rep(NA_real_,3);ad<-FALSE;rd<-NA_real_
  if(!inherits(cb,'try-error')){o<-cb$paths;p<-c(o$est.std[o$lhs=='F2'&o$rhs=='F1'],o$est.std[o$lhs=='F3'&o$rhs=='F1'],o$est.std[o$lhs=='F3'&o$rhs=='F2']);ad<-cb$admissible
   if(b==1){Q<-blockdiag(lapply(st$items,function(j)rot45(length(j))));r<-try(cbfit(gg$Z%*%t(Q),st,Q%*%st$L),silent=TRUE);if(!inherits(r,'try-error'))rd<-maxabs(r$paths$est.std-o$est.std)}
  }
  k<-k+1;res[[k]]<-data.frame(scenario=si,n=500,R2=.8,replicate=b,b21=p[1],b31=p[2],b32=p[3],PLS21=pf$P[1,2],PLS31=pf$P[1,3],PLS32=pf$P[2,3],truth21=st$B[2,1],truth31=st$B[3,1],truth32=st$B[3,2],admissible=ad,PLS_converged=pf$converged,rotation_error=rd,error=if(inherits(cb,'try-error'))as.character(cb)else '')
 };cat('CBSEM Scenario',si,'done\n')}
 res<-do.call(rbind,res);savecsv(res,'CBSEM_replicates')
 savecsv(do.call(rbind,lapply(split(res,res$scenario),function(a){v<-a[a$admissible&complete.cases(a[,4:7]),];data.frame(scenario=a$scenario[1],attempts=nrow(a),admissible=nrow(v),bias21=mean(v$b21-v$truth21),bias31=mean(v$b31-v$truth31),bias32=mean(v$b32-v$truth32),rmse21=sqrt(mean((v$b21-v$truth21)^2)),rmse31=sqrt(mean((v$b31-v$truth31)^2)),rmse32=sqrt(mean((v$b32-v$truth32)^2)),rotation_error=max(a$rotation_error,na.rm=TRUE))})),'CBSEM_summary')
 cat('lavaan',as.character(packageVersion('lavaan')),'\n')

# Locate the repository from this script, independent of the working directory.
if(.Platform$OS.type=="windows"&&!isTRUE(l10n_info()[["UTF-8"]]))invisible(suppressWarnings(try(Sys.setlocale("LC_CTYPE",".UTF-8"),silent=TRUE)))
script_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value=TRUE)[1])
repo <- dirname(normalizePath(script_file, winslash="/", mustWork=TRUE))
source(file.path(repo,"R","runtime.R"))
load_core(repo)
opt<-parse_options(list(data=file.path(repo,"data","analysis.csv"),bootstrap="2000",rotations="51",out=file.path(repo,"results","empirical"),"expect-paper"="true",mode="verified"))
nboot<-positive_int(opt$bootstrap,"bootstrap");nrot<-positive_int(opt$rotations,"rotations")
if(!opt$mode%in%c("verified","recompute"))stop("mode must be verified or recompute")
if(nboot<2)stop("bootstrap must be >=2")
if(!opt[["expect-paper"]] %in% c("true","false"))stop("expect-paper must be true or false")
if(!file.exists(opt$data))stop("Input not found: ",opt$data,". See data/README.md for the authorized, pseudonymized input.")
dat<-read.csv(opt$data,check.names=FALSE)
labels<-c(paste0("Att",1:4),paste0("PBC",1:3),paste0("BI",1:3))
part_fields<-unlist(lapply(labels,function(v)paste0(v,c("_agree_pct","_disagree_pct","_neutral_pct"))))
sn_fields<-c("IS_Family_pct","IS_Friends_pct","IS_Othernonfam_pct")
required<-c(part_fields,sn_fields)
if(!all(required%in%names(dat)))stop("Missing required numeric fields: ",paste(setdiff(required,names(dat)),collapse=", "))
if(anyDuplicated(names(dat)))stop("Duplicate column names")
if(!all(vapply(dat[required],is.numeric,logical(1))))stop("All allocation fields must be numeric")
x<-as.matrix(dat[part_fields]);sn<-as.matrix(dat[sn_fields]);N<-nrow(x)
if(N<30||any(!is.finite(c(x,sn)))||any(x<0)||any(sn<=0))stop("Need >=30 complete rows, nonnegative agreement parts and strictly positive independent influence allocations")
totals<-sapply(1:10,function(i)rowSums(x[,(3*i-2):(3*i)]))
if(maxabs(totals-100)>1e-8||maxabs(rowSums(sn)-100)>1e-8)stop("This empirical design expects original 100-point allocations. Do not silently close an entry error.")
if("cv_fold"%in%names(dat)) {
 input_fold<-dat$cv_fold
 if(anyNA(input_fold)||any(!input_fold%in%1:10)||length(unique(input_fold))!=10)stop("cv_fold must contain all ten integers 1..10")
}else{RNGkind("Mersenne-Twister","Inversion","Rejection");set.seed(20261027);input_fold<-sample(rep(1:10,length.out=N))}
input_unique<-rep(TRUE,N)
if("unique_profile_match"%in%names(dat)) {
 v<-tolower(as.character(dat$unique_profile_match));if(anyNA(v)||any(!v%in%c("true","false")))stop("unique_profile_match must be TRUE/FALSE")
 input_unique<-v=="true"
}
if(opt[["expect-paper"]]=="true")stopifnot(N==506,sum(x==0)==1827,sum(rowSums(x==0)>0)==223)
out<-prepare_output(opt$out);record_session(out)
RNGkind("Mersenne-Twister","Inversion","Rejection")
savecsv<-function(x,name)write.csv(x,file.path(out,paste0(name,".csv")),row.names=FALSE)
savecsv(data.frame(n=N,allocation_items=10,original_zero_parts=sum(x==0),respondents_with_zero=sum(rowSums(x==0)>0),input_md5=unname(tools::md5sum(opt$data)),bootstrap_requested=nboot,rotations_requested=nrot),"input_summary")
writeLines(c("Only numeric fields listed in data/README.md are used.","Extra identifiers are ignored and are not exported by this analysis.","Influence-source allocations are not a validated measure of perceived social approval."),file.path(out,"input_scope.txt"))
gn<-c('IS','Attitude','PBC','BI');groups<-list(21:22,1:8,9:14,15:20)
items<-lapply(1:11,function(i)(2*i-1):(2*i));ic<-c(rep(2,4),rep(3,3),rep(4,3),1)
inames<-c(paste0('Att',1:4),paste0('PBC',1:3),paste0('BI',1:3),'IS')
edges<-rbind(c(1,2),c(1,3),c(1,4),c(2,4),c(3,4))
# All delta values below are percentage points on the original 100-point scale.
# MR: zero parts get delta/100, positive parts preserve their original pairwise ratios.
# Smoothing: (x+delta)/(100+3*delta), changes positive-part ratios as well.
# Zero-only replacement followed by closure is a near-boundary regularization control.
methods<-data.frame(method=c('MR_0.5','MR_0.1','MR_1','smooth_0.1','smooth_0.5','smooth_1','zero_only_0.001','MR_0.001'),
 family=c(rep('multiplicative',3),rep('additive_smoothing',3),'zero_only_closure','multiplicative'),
 delta_pp=c(.5,.1,1,.1,.5,1,.001,.001))
savecsv(methods,'methods')
replace_item<-function(a,family,delta){
 p<-a/100
 if(family=='multiplicative')for(r in seq_len(nrow(p))){z<-p[r,]==0;k<-sum(z);if(k){p[r,z]<-delta/100;p[r,!z]<-p[r,!z]*(1-k*delta/100)}}
 if(family=='additive_smoothing')p<-(a+delta)/(100+ncol(a)*delta)
 if(family=='zero_only_closure'){p<-a;p[p==0]<-delta;p<-p/rowSums(p)}
 stopifnot(all(p>0),maxabs(rowSums(p)-1)<1e-12)
 p
}
make_rawZ<-function(method){do.call(cbind,c(lapply(1:10,function(i)ilr(replace_item(x[,(3*i-2):(3*i)],method$family,method$delta_pp))),list(ilr(sn))))}
Z0<-make_rawZ(methods[1,]);m0<-fit(Z0,groups,edges,items)
stopifnot(m0$converged)
savecsv(as.data.frame(Z0),'primary_ilr')
savecsv(as.data.frame(m0$scores),'construct_scores');savecsv(as.data.frame(m0$L),'raw_loading_matrix')
savecsv(strength(m0,Z0,inames,ic),'measurement')
savecsv(data.frame(item=inames,do.call(rbind,lapply(1:11,function(i)ilrinv(matrix(m0$L[items[[i]],ic[i]],nrow=1),helm(3))))),'compositional_slopes')
savecsv(data.frame(construct=gn,R2=m0$r2),'R2')
set.seed(2026103001);rot<-rotation_test(Z0,groups,edges,items,rep(list(helm(3)),11),'empirical',nrot)
savecsv(rot,'rotations');stopifnot(max(rot$path)<1e-7,max(rot$inverse_ilr)<1e-7,max(rot$predictions)<1e-7)
fold<-input_fold
savecsv(data.frame(analysis_row=seq_len(N),fold=fold),'cv_folds')
sens<-list();allpaths<-list();allr2<-list();allpred<-list();allboot<-list();nonconv<-0
for(k in seq_len(nrow(methods))){
 method<-methods[k,];Z<-make_rawZ(method);m<-alignfit(fit(Z,groups,edges,items),m0)
 if(opt$mode=='verified'){
  cached<-read.csv(gzfile(file.path(repo,'verified','bootstrap_paths.csv.gz')))
  keep<-cached$method==method$method
  stopifnot(sum(keep)==nboot,nboot==2000L)
  boot<-as.matrix(cached[keep,paste0('X',1:5)])
  nbad<-sum(!complete.cases(boot))
 }else{
 set.seed(2026103002) # Paired respondent resamples across preprocessing choices.
 boot<-matrix(NA_real_,nboot,5);nbad<-0L
 for(b in seq_len(nboot)){ix<-sample.int(N,replace=TRUE);fb<-try(fit(Z[ix,],groups,edges,items),silent=TRUE)
  if(inherits(fb,'try-error')||!fb$converged){nbad<-nbad+1L;next}
  sg<-sign(colSums(fb$scores*m$scores[ix,]));sg[sg==0]<-1
  boot[b,]<-(fb$P*outer(sg,sg))[edges]
 }
 }
 allboot[[k]]<-data.frame(method=method$method,replicate=seq_len(nboot),boot)
 p<-data.frame(method=method$method,source=gn[edges[,1]],target=gn[edges[,2]],estimate=m$P[edges],bootstrap_SE=apply(boot,2,sd,na.rm=TRUE),lower=apply(boot,2,quantile,.025,na.rm=TRUE),upper=apply(boot,2,quantile,.975,na.rm=TRUE),successful=nboot-nbad,requested=nboot)
 allpaths[[k]]<-p;allr2[[k]]<-data.frame(method=method$method,construct=gn,R2=m$r2)
 pred<-lmpr<-rotpr<-centerpr<-matrix(NA_real_,N,22)
 Q<-blockdiag(rep(list(rot45(2)),11));ZR<-Z%*%t(Q);ri<-lapply(groups,function(j)drop(Q[j,j,drop=FALSE]%*%rep(1,length(j))))
 cvfail<-0L
 for(f in 1:10){tr<-fold!=f;te<-!tr;fm<-fit(Z[tr,],groups,edges,items);fr<-fit(ZR[tr,],groups,edges,items,init=ri)
  if(!fm$converged||!fr$converged)cvfail<-cvfail+1L
  pred[te,]<-predictfit(fm,Z[te,]);rotpr[te,]<-predictfit(fr,ZR[te,])%*%Q
  bb<-qr.solve(cbind(1,Z[tr,21:22,drop=FALSE]),Z[tr,,drop=FALSE]);lmpr[te,]<-cbind(1,Z[te,21:22,drop=FALSE])%*%bb
  centerpr[te,]<-matrix(colMeans(Z[tr,,drop=FALSE]),sum(te),22,byrow=TRUE)
 }
 allpred[[k]]<-do.call(rbind,lapply(8:10,function(i){j<-items[[i]];a<-Z[,j]-pred[,j];b<-Z[,j]-lmpr[,j];c<-Z[,j]-centerpr[,j]
  data.frame(method=method$method,item=inames[i],PLS_Aitchison_RMSE=sqrt(mean(rowSums(a*a))),PLS_mean_Aitchison=mean(sqrt(rowSums(a*a))),LM_Aitchison_RMSE=sqrt(mean(rowSums(b*b))),LM_mean_Aitchison=mean(sqrt(rowSums(b*b))),Center_Aitchison_RMSE=sqrt(mean(rowSums(c*c))),Center_mean_Aitchison=mean(sqrt(rowSums(c*c))),rotation_prediction_error=maxabs(pred[,j]-rotpr[,j]))}))
 if(k==1){savecsv(data.frame(analysis_row=seq_len(N),pred),'cv_predictions');savecsv(data.frame(analysis_row=seq_len(N),lmpr),'cv_predictions_LM');savecsv(data.frame(analysis_row=seq_len(N),centerpr),'cv_predictions_center')}
 sens[[k]]<-data.frame(method=method$method,family=method$family,delta_pp=method$delta_pp,t(setNames(m$P[edges],paste0('path',1:5))),max_path_change=maxabs(m$P-m0$P),iterations=m$iterations,converged=m$converged,bootstrap_failed=nbad,cv_failed=cvfail,rotation_prediction_error=maxabs(pred-rotpr))
 nonconv<-nonconv+nbad+cvfail+as.integer(!m$converged)
 cat(method$method,': bootstrap',nboot-nbad,'/',nboot,', paths',m$P[edges],'\n');flush.console()
}
savecsv(do.call(rbind,allpaths),'paths_all_methods');savecsv(allpaths[[1]],'paths')
savecsv(do.call(rbind,allr2),'R2_all_methods');savecsv(do.call(rbind,allpred),'prediction_all_methods');savecsv(allpred[[1]],'prediction')
savecsv(do.call(rbind,allboot),'bootstrap_replicates');savecsv(do.call(rbind,sens),'zero_sensitivity')
unique_only<-input_unique
controls<-list(unique_profile_only=unique_only,positive_complete_cases=rowSums(x==0)==0)
ctl<-list()
for(nm in names(controls)){ix<-controls[[nm]];if(sum(ix)<20){warning('Skipping insufficient control sample: ',nm);next};f<-fit(Z0[ix,],groups,edges,items);sg<-sign(colSums(f$scores*m0$scores[ix,]));sg[sg==0]<-1;pp<-(f$P*outer(sg,sg))[edges]
 ctl[[nm]]<-data.frame(control=nm,n=sum(ix),source=gn[edges[,1]],target=gn[edges[,2]],estimate=pp,primary=m0$P[edges],difference=pp-m0$P[edges],converged=f$converged)
}
if(length(ctl))savecsv(do.call(rbind,ctl),'sample_sensitivity')
cat('Completed empirical analysis; nonconverged resamples:',nonconv,'\n')

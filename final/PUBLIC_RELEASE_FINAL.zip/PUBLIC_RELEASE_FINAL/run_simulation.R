# Locate the repository from this script, independent of the working directory.
if(.Platform$OS.type=="windows"&&!isTRUE(l10n_info()[["UTF-8"]]))invisible(suppressWarnings(try(Sys.setlocale("LC_CTYPE",".UTF-8"),silent=TRUE)))
script_file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value=TRUE)[1])
repo <- dirname(normalizePath(script_file, winslash="/", mustWork=TRUE))
source(file.path(repo,"R","runtime.R"))
load_core(repo)
opt<-parse_options(list(reps="200",sizes="100,500,2000",out=file.path(repo,"results","simulation")))
reps<-positive_int(opt$reps,"reps");sizes<-vapply(strsplit(opt$sizes,",",fixed=TRUE)[[1]],positive_int,integer(1),name="sizes")
if(anyNA(sizes)||any(sizes<10))stop("sizes must be comma-separated integers >=10")
out<-prepare_output(opt$out);record_session(out)
RNGkind("Mersenne-Twister","Inversion","Rejection")
source(file.path(repo,"vendor","generator_reference.R"))
savecsv<-function(x,name)write.csv(x,file.path(out,paste0(name,".csv")),row.names=FALSE)
rots<-NULL
sedges<-rbind(c(1,2),c(1,3),c(2,3)); genrows<-list(); mc<-list(); k<-0L
set.seed(20261025)
for(si in 1:3) {
 st<-setup(scenarios[[si]],c(.8,.8));gen<-generate(st,700)
 rots<-rbind(rots,rotation_test(gen$Z,st$groups,sedges,st$items,st$psis,paste0('scenario',si),25))
 for(rho in c(.5,.8,.9)) {
  st<-setup(scenarios[[si]],rep(rho,2))
  # Directly compare the original generator with the transparent recursive formula.
  ix<-unlist(lapply(which(scenarios[[si]]$assign==1),function(i)rep(1,length(st$items[[i]]))))
  iy<-unlist(lapply(which(scenarios[[si]]$assign>1),function(i)rep(scenarios[[si]]$assign[i]-1,length(st$items[[i]]))))
  B0<-matrix(c(0,.36,.76,0,0,scenarios[[si]]$b,0,0,0),3)
  og<-gscmcovrr1(B0,ix,iy,rowSums(st$L)[unlist(st$groups[1])],rowSums(st$L)[unlist(st$groups[2:3])],matrix(1),rep(rho,2))
  Smv<-st$L%*%st$S%*%t(st$L)+diag(st$theta)
  genrows[[length(genrows)+1]]<-data.frame(scenario=si,R2_eta1=rho,R2_eta2=rho,b21=st$B[2,1],b31=st$B[3,1],b32=st$B[3,2],min_residual=min(st$theta),min_eigen=min(eigen(Smv,symmetric=TRUE,only.values=TRUE)$values),upstream_cov_error=maxabs(og$S-Smv),upstream_B_error=maxabs(og$B-st$B))
  for(n in sizes) for(rep in seq_len(reps)) {
   gen<-generate(st,n);ZZ<-gen$Z
   # Inverse ILR and forward transform explicitly exercise composition construction.
   ZZ<-do.call(cbind,lapply(seq_along(st$items),function(i) ilr(ilrinv(ZZ[,st$items[[i]],drop=FALSE],st$psis[[i]]))))
   fa<-fit(ZZ,st$groups,sedges,st$items)
   fo<-fit(ZZ,st$groups,sedges,st$items,'column')
   # CLR uses the exact same geometry, item scaling and transported initialization.
   V<-blockdiag(lapply(st$psis,t));clrZ<-ZZ%*%t(V)
   citems<-lapply(seq_along(st$psis),function(i){e<-cumsum(sapply(st$psis,ncol));seq.int(if(i==1)1 else e[i-1]+1,e[i])})
   cg<-lapply(1:3,function(g)unlist(citems[scenarios[[si]]$assign==g]))
   ci<-lapply(st$groups,function(j)drop(V[,j,drop=FALSE]%*%rep(1,length(j))))
   # Extract only the current construct entries from the transported full vector.
   ci<-lapply(1:3,function(g)ci[[g]][cg[[g]]])
   fc<-alignfit(fit(clrZ,cg,sedges,citems,init=ci),fa)
   oracle<-matrix(0,3,3);tt<-std(gen$latent)
   for(g in 2:3){pa<-seq_len(g-1);oracle[pa,g]<-qr.solve(tt[,pa,drop=FALSE],tt[,g])}
   for(meth in c('ILR-trace','ILR-column','CLR-trace','oracle')) {
    obj<-switch(meth,'ILR-trace'=fa,'ILR-column'=fo,'CLR-trace'=fc,'oracle'=list(P=oracle,converged=TRUE))
    k<-k+1L;mc[[k]]<-data.frame(scenario=si,n=n,R2=rho,replicate=rep,method=meth,
       b21=obj$P[1,2],b31=obj$P[1,3],b32=obj$P[2,3],truth21=st$B[2,1],truth31=st$B[3,1],truth32=st$B[3,2],converged=obj$converged,
       clr_ilr_max=maxabs(fa$P-fc$P))
   }
  }
  cat('MC completed Scenario',si,'R2',rho,'repetitions',reps,'\n');flush.console()
 }
}
savecsv(do.call(rbind,genrows),'generator_audit'); savecsv(rots,'rotation_differences')
stopifnot(max(rots$path)<1e-7,max(rots$inverse_ilr)<1e-7,max(rots$predictions)<1e-7,all(rots$converged))
mc<-do.call(rbind,mc);savecsv(mc,'benchmark_replicates')
summarymc<-do.call(rbind,lapply(split(mc,interaction(mc$scenario,mc$n,mc$R2,mc$method,drop=TRUE)),function(a){
 data.frame(scenario=a$scenario[1],n=a$n[1],R2=a$R2[1],method=a$method[1],replicates=nrow(a),
 bias21=mean(a$b21-a$truth21),bias31=mean(a$b31-a$truth31),bias32=mean(a$b32-a$truth32),
 rmse21=sqrt(mean((a$b21-a$truth21)^2)),rmse31=sqrt(mean((a$b31-a$truth31)^2)),rmse32=sqrt(mean((a$b32-a$truth32)^2)),
 mcse_bias21=sd(a$b21-a$truth21)/sqrt(nrow(a)),mcse_bias31=sd(a$b31-a$truth31)/sqrt(nrow(a)),mcse_bias32=sd(a$b32-a$truth32)/sqrt(nrow(a)),nonconverged=sum(!a$converged),clr_ilr_max=max(a$clr_ilr_max))}))
savecsv(summarymc,'benchmark_summary')

cat("Simulation complete:",out,"\n")

# Public entry point: regenerate final tables' inputs without repeating completed simulations.
if(.Platform$OS.type=='windows'&&!isTRUE(l10n_info()[['UTF-8']]))invisible(suppressWarnings(try(Sys.setlocale('LC_CTYPE','.UTF-8'),silent=TRUE)))
sf<-sub('^--file=','',grep('^--file=',commandArgs(FALSE),value=TRUE)[1]);repo<-dirname(normalizePath(sf,winslash='/'))
source(file.path(repo,'R','runtime.R'));load_core(repo)
opt<-parse_options(list(mode='verified',out=file.path(repo,'outputs')))
if(!opt$mode%in%c('verified','recompute'))stop('mode must be verified or recompute')
out<-prepare_output(opt$out);record_session(out)
exe<-file.path(R.home('bin'),if(.Platform$OS.type=='windows')'Rscript.exe'else'Rscript')
run<-function(script,args){st<-system2(exe,c('--vanilla',shQuote(file.path(repo,script)),vapply(args,shQuote,character(1))));if(st!=0)stop('Failed: ',script)}
savecsv<-function(x,p)write.csv(x,file.path(out,p),row.names=FALSE)
if(opt$mode=='recompute'){
 run('run_simulation.R',c('--reps=200','--sizes=100,500,2000',paste0('--out=',file.path(out,'simulation'))))
 run('run_factor_benchmark.R',c('--reps=100',paste0('--out=',file.path(out,'factor_ml'))))
}else{
 dir.create(file.path(out,'simulation'),showWarnings=FALSE);dir.create(file.path(out,'factor_ml'),showWarnings=FALSE)
 mc<-read.csv(gzfile(file.path(repo,'verified','simulation_draws.csv.gz')))
 cb<-read.csv(gzfile(file.path(repo,'verified','factor_ml_draws.csv.gz')))
 file.copy(file.path(repo,'verified','scenario_rotations.csv'),file.path(out,'simulation','rotation_differences.csv'),overwrite=TRUE)
 stopifnot(nrow(mc)==21600,nrow(cb)==200,all(mc$converged))
 write.csv(mc,file.path(out,'simulation','benchmark_replicates.csv'),row.names=FALSE)
 sm<-do.call(rbind,lapply(split(mc,interaction(mc$scenario,mc$n,mc$R2,mc$method,drop=TRUE)),function(a){
 data.frame(scenario=a$scenario[1],n=a$n[1],R2=a$R2[1],method=a$method[1],replicates=nrow(a),
 bias21=mean(a$b21-a$truth21),bias31=mean(a$b31-a$truth31),bias32=mean(a$b32-a$truth32),
 rmse21=sqrt(mean((a$b21-a$truth21)^2)),rmse31=sqrt(mean((a$b31-a$truth31)^2)),rmse32=sqrt(mean((a$b32-a$truth32)^2)),
 mcse_bias21=sd(a$b21-a$truth21)/sqrt(nrow(a)),mcse_bias31=sd(a$b31-a$truth31)/sqrt(nrow(a)),mcse_bias32=sd(a$b32-a$truth32)/sqrt(nrow(a)),nonconverged=sum(!a$converged),clr_ilr_max=max(a$clr_ilr_max))}))
 write.csv(sm,file.path(out,'simulation','benchmark_summary.csv'),row.names=FALSE)
 write.csv(cb,file.path(out,'factor_ml','CBSEM_replicates.csv'),row.names=FALSE)
 cs<-do.call(rbind,lapply(split(cb,cb$scenario),function(a){v<-a[a$admissible&complete.cases(a[,4:7]),];data.frame(scenario=a$scenario[1],attempts=nrow(a),admissible=nrow(v),bias21=mean(v$b21-v$truth21),bias31=mean(v$b31-v$truth31),bias32=mean(v$b32-v$truth32),rmse21=sqrt(mean((v$b21-v$truth21)^2)),rmse31=sqrt(mean((v$b31-v$truth31)^2)),rmse32=sqrt(mean((v$b32-v$truth32)^2)),rotation_error=max(a$rotation_error,na.rm=TRUE))}))
 write.csv(cs,file.path(out,'factor_ml','CBSEM_summary.csv'),row.names=FALSE)
}
run('run_empirical.R',c(paste0('--mode=',opt$mode),'--bootstrap=2000','--rotations=51','--expect-paper=true',paste0('--out=',file.path(out,'empirical'))))
cat('Numerical outputs complete. Generate LaTeX tables with: python make_tables.py --results="',out,'"\n',sep='')

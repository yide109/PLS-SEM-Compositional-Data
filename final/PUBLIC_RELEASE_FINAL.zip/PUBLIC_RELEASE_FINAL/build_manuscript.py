"""Compile the formal manuscript after reproduce.py has generated its ten tables."""
from pathlib import Path
import argparse,shutil,subprocess
repo=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--results',default=str(repo/'outputs'));p.add_argument('--engine',default=shutil.which('tectonic') or shutil.which('latexmk'));a=p.parse_args()
if not a.engine:p.error('Install Tectonic or latexmk and provide --engine=/path/to/executable')
results=Path(a.results).resolve();build=results/'paper';build.mkdir(parents=True,exist_ok=True)
if len(list((results/'tables').glob('*.tex')))!=10:p.error('Run reproduce.py first: ten generated tables are required')
shutil.copytree(results/'tables',build/'tables',dirs_exist_ok=True)
shutil.copy2(repo/'paper'/'manuscript.tex',build/'FINAL_MANUSCRIPT.tex')
if 'tectonic' in Path(a.engine).stem.lower():cmd=[a.engine,'--keep-logs','--keep-intermediates','FINAL_MANUSCRIPT.tex']
else:cmd=[a.engine,'-pdf','-interaction=nonstopmode','-halt-on-error','FINAL_MANUSCRIPT.tex']
subprocess.run(cmd,cwd=build,check=True)
print('Formal manuscript:',build/'FINAL_MANUSCRIPT.pdf')

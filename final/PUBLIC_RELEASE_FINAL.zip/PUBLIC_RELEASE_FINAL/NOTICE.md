# Rights and authorization

The corresponding author confirmed public-sharing authority for both the pseudonymized agreement allocations and independent influence allocations. Direct identifiers and private source-linkage records are excluded. No new software/data reuse license has been chosen on the authors' behalf.

Core estimator, scenario and zero-handling expressions are taken from the audited manuscript analysis. The reversed-Helmert geometry and the attributed generator reference preserve the authors' upstream convention. The generator reference has a scalar as.numeric(tau) compatibility adjustment for recent R versions, without changing its numeric covariance/path results. No third-party package source is distributed. lavaan, if installed separately, retains its own license.

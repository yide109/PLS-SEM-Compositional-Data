# Software environment

The completed Monte Carlo and bootstrap draws were originally computed in R 4.6.1 on Windows. Final-package point fits, predictions and verified replay were checked in R 4.6.2 (2026-10-29 ucrt). The factor benchmark used lavaan 0.7.2. Table generation uses Python 3.12 and the standard library only. Base R covers the core geometry, PLS, prediction and numerical checks. Runtime sessionInfo.txt is written into each output directory; no machine-specific library paths are bundled.

LaTeX tables are plain booktabs/longtable fragments; those packages are needed by the separate manuscript source. The numerical release does not need a LaTeX compiler, Codex, Node, Excel, or proprietary software. The submission PDF was compiled separately using Tectonic 0.17.0 and visually checked. No new external method or package was introduced for the main estimation.

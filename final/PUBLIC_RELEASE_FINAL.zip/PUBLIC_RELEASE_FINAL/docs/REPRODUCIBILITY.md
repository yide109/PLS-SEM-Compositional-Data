# Numerical workflow, seeds and table mapping

Run `python reproduce.py` from a local copy of this directory. The script resolves source paths relative to itself. Rscript may be supplied through --rscript; no original Windows directory, private source workbook or drafting runtime is needed. The default output directory is outputs/ and may be overridden.

## Verified mode

The supplied verified numerical draws are hash-checked. The 21,600 Monte Carlo comparator rows correspond to 5,400 samples (3 scenarios x 3 n values x 3 equation targets x 200 replications). There are 200 paired factor-ML samples and 16,000 requested full-model bootstrap draws. Tables are computed from these draws without repeating the completed experiments. Empirical point models, 51 rotations, fixed-fold prediction for all eight zero settings, the training-center baseline and sample sensitivities are evaluated from analysis.csv. The 15,999 successful bootstrap draws produce method-specific standard errors and percentile intervals; failed records remain missing, not silently imputed. The primary setting has 2,000 successful fits.

## Full recomputation

Use `python reproduce.py --mode=recompute`. Base R handles all primary models. Install lavaan separately for the factor-ML benchmark. Defaults preserve the full sample-size order (100,500,2000), 200 replications and target grid (.5,.8,.9). Smaller replication/sample-size settings change later random-number consumption and are not the full paper experiment.

RNG kind: Mersenne-Twister/Inversion/Rejection. Main Monte Carlo seed 20261025; factor-ML seed 20261029; empirical rotation seed 2026103001; paired respondent-bootstrap seed 2026103002; fold seed 20261027. The released cv_fold column preserves the actual fold groups. Bootstrap centering, item scaling and score weights are refitted within each resample, and signs align to each full-sample oriented reference.

Whole-item trace scaling uses the covariance trace of each complete composition in the training sample. Initial weights are ones in the documented reversed-Helmert basis, and are transported for rotations. Scores have sample variance one, stopping tolerance is 1e-10, and iteration limit is 1000. Final outer slopes use raw ILR units. Prediction supplies only root IS inputs; a center uses the training-sample geometric/compositional center, represented by mean ILR coordinates.

## Final tables

make_tables.py generates compcr.tex, run_scope.tex, rotation.tex, benchmark.tex, cbsem.tex, measurement.tex, paths.tex, prediction.tex, sensitivity.tex and items.tex. Each file's input mapping is exported in table_sources.json. The scope/benchmark tables use simulation draws; the paired factor table uses ML draws. Paths and sensitivity use raw observations plus bootstrap draws, with current fitting rules. Rotations use `simulation/rotation_differences.csv` (the 75 completed scenario records in verified mode, newly generated in recompute mode) and current 51 application rotations. Prediction is recalculated from the released data/folds and includes the center baseline. The appendix is generated from items.csv. There are no separate result figures in the formal paper.

The conditional iteration result builds on existing regression-coordinate invariance. Neither the proof nor the numeric checks establishes reliability, causal identification, a zero mechanism or common-factor consistency. Scope is also limited by the illustrative normal generators and the documented questionnaire/matching assumptions.

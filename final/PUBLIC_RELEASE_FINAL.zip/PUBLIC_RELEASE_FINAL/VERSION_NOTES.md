# Final version and material data correction

Use the `final/` version entry for the formal paper. Legacy material elsewhere in the repository is retained for version history and must not be combined with the final input dataset or result tables.

A material input-construction problem in an earlier application used nominal subjective-norm coordinates that duplicated logratio information from a behavioral-intention outcome item. The final analysis excludes those coordinates and uses independently collected Family/Friends/Other non-family allocations for the same 506 participants. This is not a newly collected 506-person sample. Record matching and its two-row ordering assumption are disclosed. The old strong structural interpretations are not supported by the current influence-source results.

Observed agreement allocations and original zero information are used under explicit replacement/smoothing sensitivities. COMP-CR is not used as reliability; measurement magnitudes are descriptive. This statement preserves the material version/data change without distributing erroneous variables, previous estimates, internal audit logs or private linkage records in this final directory. Git history is not rewritten.


## Version 1.0.1 — editorial correction, 31 October 2026

The formal paper's availability statement now links directly to the final release and accurately describes file checksums and reproduction instructions. Numerical inputs, analysis code, tables and results are unchanged. The reviewer response is delivered separately and omits the administrative editorial-office contact note.

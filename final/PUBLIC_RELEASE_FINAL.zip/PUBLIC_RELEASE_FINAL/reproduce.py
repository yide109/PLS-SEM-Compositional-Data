"""One-command final-release reproduction using only this directory's inputs."""
from pathlib import Path
import argparse,subprocess,sys,shutil,hashlib,json
repo=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--rscript',default=shutil.which('Rscript'));p.add_argument('--mode',choices=['verified','recompute'],default='verified');p.add_argument('--out',default=str(repo/'outputs'));a=p.parse_args()
if not a.rscript:p.error('Rscript was not found; provide --rscript=/path/to/Rscript')
out=Path(a.out).resolve()
for item in json.loads((repo/'verified/manifest.json').read_text(encoding='utf-8')):
 if hashlib.sha256((repo/item['path']).read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('Verified numerical input changed: '+item['path'])
subprocess.run([a.rscript,'--vanilla',str(repo/'run_final.R'),'--mode='+a.mode,'--out='+str(out)],check=True,cwd=repo)
subprocess.run([sys.executable,str(repo/'make_tables.py'),'--results='+str(out),'--out='+str(out/'tables')],check=True,cwd=repo)
print('Reproduction complete:',out)
